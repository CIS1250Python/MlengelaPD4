#-----------------------------------------------------------------------
# MlengelaDP4
# Programmer: Daudi Mlengela
# Email: mlengelad@cnm.edu
# Purpose: create a text based rock, paper, scissors game
#-----------------------------------------------------------------------

import random
random.randrange(3)
0
random.randrange(3)
1
random.randrange(3)
2
choices=['rock','paper','scisors']
compchoice = choices[random.randrange(3)]
compchoice

print("Welcome to super RPS 3000, the best rock paper scissors game in the world.\n")

playing = True

while playing:

   playerWins   = 0
   computerWins = 0

   while playerWins < 2 and computerWins < 2:
      
      playerChoice = input("Please select \"rock,\" \"paper,\" or \"scissors:\" ")

      value = random.randint(0, 2)

      if value == 0:
         computerChoice = "rock"
      elif value == 1:
         computerChoice = "paper"
      else:
         computerChoice = "scissors"

      outcome = "N/A"

      if playerChoice == "rock":

         if computerChoice == "rock":
            outcome = "It's a tie"

         elif computerChoice == "paper":
            outcome = "You lost"
            computerWins += 1

         elif computerChoice == "scissors":
            outcome = "You won"
            playerWins += 1

      elif playerChoice == "paper":

         if computerChoice == "rock":
            outcome = "You won"
            playerWins += 1

         elif computerChoice == "paper":
            outcome = "It's a tie"

         elif computerChoice == "scissors":
            outcome = "You lost"
            computerWins += 1

      elif playerChoice == "scissors":

         if computerChoice == "rock":
            outcome = "You lose"
            computerWins += 1

         elif computerChoice == "paper":
            outcome = "You win"
            playerWins += 1

         elif computerChoice == "scissors":
            outcome = "It's a tie"

      print(f"You selected: {playerChoice}; the computer selected: {computerChoice}")
      print(outcome + "!")
      print(f"The game's score is: {playerWins} - {computerWins}.")

   answer = input("Do you want to play another round of rock paper scissors? (yes/no) ")

   if answer == "no":
      playing = False







      
